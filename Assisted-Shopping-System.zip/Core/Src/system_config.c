#include "system_config.h"

void System_Config(void) {
    // Initialize system clock, GPIO, etc.
}
